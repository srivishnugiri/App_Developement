import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../asserts/Admin.css';

const Admin = () => {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('http://localhost:3060/api/registrations');
        if (res.ok) {
          const data = await res.json();
          setUsers(data);
        } else {
          console.log('Failed to fetch users');
        }
      } catch (error) {
        console.log('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);
  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(search.toLowerCase()) ||
    user.email.toLowerCase().includes(search.toLowerCase()) ||
    user.event.toLowerCase().includes(search.toLowerCase()) ||
    user.mobile.toLowerCase().includes(search.toLowerCase()) ||
    user.date.toLowerCase().includes(search.toLowerCase())
  );
  
  return (
    <div className="admin-body" >
      <div className="header">
        <Link to="/AdminUsers" style={{ textDecoration: 'none' }}><div>DashBoard</div></Link>
        <Link to="/Admin" style={{ textDecoration: 'none' }}><div>Bookings</div></Link>
        <Link to="/AdminVender" style={{ textDecoration: 'none' }}><div>Users</div></Link>
        <Link to="/SignIn" style={{ textDecoration: 'none' }}><div>Sign Out</div></Link>
      </div>
      <div className="Appbar">
        <p>Bookings</p>
        <input type="text" name="search" onChange={handleSearchChange} value={search} placeholder="Search" />

      </div>
      <div className="form-container" style={{ marginLeft: '12%' }}>
        <div>
          <h2>Hall Booked</h2>
          <table className='table table-striped' >
            <thead>
              <tr>
                <td className='font-weight-bold'>Name</td>
                <td className='font-weight-bold'>Email</td>
                <td className='font-weight-bold'>Event</td>
                <td className='font-weight-bold'>Mobile No</td>
                <td className='font-weight-bold'>Date</td>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr key={user.id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.event}</td>
                    <td>{user.mobile}</td>
                    <td>{user.date}</td>
              
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5}>No users</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Admin;



/*import React from 'react';
import { Link } from 'react-router-dom';
import '../asserts/Admin.css';
import UserTable from './UserTable';
const Admin = ({ users, editRow, deleteUser,addUser, closeForm }) => {
  return (
    
    <div className="admin-body">
          <div className='header'>
          <Link to='/AdminUsers' style={{textDecoration:'none'}} users={users}><div>DashBoard</div></Link>
          <Link to='/Admin' style={{textDecoration:'none'}}><div>Bookings</div></Link>
          <Link to='/AdminVender' style={{textDecoration:'none'}}><div>Users</div></Link>

         
     <Link to='/SignIn' style={{textDecoration:'none'}}><div>Sign Out</div></Link>
      </div>
      <div class='Appbar'>
          <p>Bookings</p>
          <input type="text" name="search" placeholder='Search' />

        </div>
      <form action="/submit_booking" className="form-container">

              <div>
          <h2 style={{marginLeft:'2%'}}>Booking users</h2>
          <UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
        </div>
      </form>
    </div>
  );
};

export default Admin;
*/